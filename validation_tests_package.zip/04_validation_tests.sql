-- 04_validation_tests.sql
-- Validation tests T1-T4 for Project 1
-- Run after:
--   00_schema.sql
--   01_load.sql
--   02_views.sql
--
-- IMPORTANT:
-- T2 and T3 are supposed to produce MySQL errors.
-- Run each intentional-error INSERT separately in MySQL Workbench.
-- T4 uses a transaction and ROLLBACK so the temporary test data is removed.

USE local_services;

-- =========================================================
-- T1: Real-snapshot counts and source/relationship checks
-- =========================================================

SELECT COUNT(*) AS business_count
FROM business;

SELECT COUNT(*) AS service_count
FROM service;

SELECT COUNT(*) AS category_count
FROM service_category;

SELECT COUNT(*) AS offering_count
FROM business_service;

SELECT COUNT(DISTINCT publisher) AS publisher_count
FROM source;

-- Expected: 0
SELECT COUNT(*) AS invalid_business_source_links
FROM business AS b
LEFT JOIN source AS s
    ON b.source_id = s.source_id
WHERE s.source_id IS NULL;

-- Expected: 0
SELECT COUNT(*) AS invalid_offering_source_links
FROM business_service AS bs
LEFT JOIN source AS s
    ON bs.source_id = s.source_id
WHERE s.source_id IS NULL;

-- Expected: 0
SELECT COUNT(*) AS invalid_offering_business_links
FROM business_service AS bs
LEFT JOIN business AS b
    ON bs.business_id = b.business_id
WHERE b.business_id IS NULL;

-- Expected: 0
SELECT COUNT(*) AS invalid_offering_service_links
FROM business_service AS bs
LEFT JOIN service AS s
    ON bs.service_id = s.service_id
WHERE s.service_id IS NULL;

-- Expected: 0
SELECT COUNT(*) AS duplicate_business_service_pairs
FROM (
    SELECT business_id, service_id, COUNT(*) AS pair_count
    FROM business_service
    GROUP BY business_id, service_id
    HAVING COUNT(*) > 1
) AS duplicate_pairs;


-- =========================================================
-- T2: Foreign-key rejection
-- Run the two INSERT statements below ONE AT A TIME.
-- Each INSERT SHOULD FAIL.
-- =========================================================

-- T2A: nonexistent business_id
INSERT INTO business_service
    (business_id, service_id, source_id, raw_row_ref)
VALUES
    (999999, 100, 'SID1', 'T2_BAD_BUSINESS');

-- Expected:
-- MySQL rejects the row because business_id 999999 does not exist.


-- T2B: nonexistent service_id
INSERT INTO business_service
    (business_id, service_id, source_id, raw_row_ref)
VALUES
    (1, 999999, 'SID1', 'T2_BAD_SERVICE');

-- Expected:
-- MySQL rejects the row because service_id 999999 does not exist.


-- After both rejected INSERTs, this should return 0 rows.
SELECT *
FROM business_service
WHERE raw_row_ref IN ('T2_BAD_BUSINESS', 'T2_BAD_SERVICE');


-- =========================================================
-- T3: Duplicate business-service rejection
-- This INSERT SHOULD FAIL.
-- =========================================================

INSERT INTO business_service
    (business_id, service_id, source_id, raw_row_ref)
SELECT
    business_id,
    service_id,
    source_id,
    'T3_DUPLICATE'
FROM business_service
ORDER BY business_id, service_id
LIMIT 1;

-- Expected:
-- MySQL error 1062 / duplicate primary-key entry because
-- (business_id, service_id) is already present.

-- This should return 0 rows.
SELECT *
FROM business_service
WHERE raw_row_ref = 'T3_DUPLICATE';


-- =========================================================
-- T4: Isolated temporary fixture
-- Tests missing website, absent offering, LEFT JOIN behavior,
-- NOT EXISTS behavior, and provider counting.
-- =========================================================

START TRANSACTION;

INSERT INTO source
    (source_id, publisher, page_title, url,
     collection_date, raw_file_path)
VALUES
    ('TESTSRC',
     'Test Publisher',
     'Validation Test Page',
     'https://example.com/test',
     '2026-10-05',
     'test_fixture.csv');

INSERT INTO service_category
    (category_id, category_name)
VALUES
    ('T', 'Test Category');

INSERT INTO service
    (service_id, service_name, category_id)
VALUES
    (9001, 'Test Service A', 'T'),
    (9002, 'Test Service B', 'T');

INSERT INTO business
    (business_id, business_name, address, city,
     website, source_id, raw_row_ref)
VALUES
    (9001,
     'Test Business One',
     '1 Test Street',
     'Kirksville',
     NULL,
     'TESTSRC',
     'TEST_BUS_1'),
    (9002,
     'Test Business Two',
     '2 Test Street',
     'Kirksville',
     'https://example.com',
     'TESTSRC',
     'TEST_BUS_2');

-- Both test businesses offer Service A.
-- Neither offers Service B.
INSERT INTO business_service
    (business_id, service_id, source_id, raw_row_ref)
VALUES
    (9001, 9001, 'TESTSRC', 'TEST_OFFER_1'),
    (9002, 9001, 'TESTSRC', 'TEST_OFFER_2');


-- T4A / Q3 behavior
-- Expected: Test Service A | 2
SELECT
    s.service_name,
    COUNT(DISTINCT bs.business_id) AS provider_count
FROM service AS s
JOIN business_service AS bs
    ON s.service_id = bs.service_id
WHERE s.service_id = 9001
GROUP BY s.service_id, s.service_name;


-- T4B / Q4 behavior
-- Expected: both test businesses, because neither has Service B.
SELECT
    b.business_id,
    b.business_name
FROM business AS b
WHERE b.business_id IN (9001, 9002)
  AND NOT EXISTS (
      SELECT 1
      FROM business_service AS bs
      WHERE bs.business_id = b.business_id
        AND bs.service_id = 9002
  )
ORDER BY b.business_id;


-- T4C / Q5 behavior
-- Expected:
-- 9001 | Test Service A | 9001
-- 9002 | Test Service B | NULL
SELECT
    s.service_id,
    s.service_name,
    bs.business_id AS matched_business_id
FROM service AS s
LEFT JOIN business_service AS bs
    ON s.service_id = bs.service_id
   AND bs.business_id = 9001
WHERE s.service_id IN (9001, 9002)
ORDER BY s.service_id;


-- T4D / Q6 behavior
-- Expected: 9001 | Test Business One | Kirksville
SELECT
    business_id,
    business_name,
    city
FROM directory_view
WHERE website IS NULL
  AND business_id = 9001;


-- Remove all T4 test records.
ROLLBACK;


-- Final cleanup check: expected 0 rows.
SELECT *
FROM business
WHERE business_id IN (9001, 9002);

SELECT *
FROM source
WHERE source_id = 'TESTSRC';
