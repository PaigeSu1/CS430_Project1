# Validation Results

These results are based on the supplied cleaned CSV snapshot.  
T2, T3, and T4 still need to be executed in MySQL Workbench so the submitted log contains the actual MySQL messages/results.

## T1 — Real snapshot

| Check | Required / Expected | Actual | Status |
|---|---:|---:|---|
| Businesses | at least 15 | 15 | PASS |
| Services | at least 4 | 38 | PASS |
| Categories | at least 2 | 7 | PASS |
| Business-service offerings | at least 20 | 46 | PASS |
| Distinct publishers | at least 2 | 15 | PASS |
| Invalid business → source links | 0 | 0 | PASS |
| Invalid offering → source links | 0 | 0 | PASS |
| Invalid offering → business links | 0 | 0 | PASS |
| Invalid offering → service links | 0 | 0 | PASS |
| Duplicate business-service pairs | 0 | 0 | PASS |

### Separate data-quality issue

`source.csv` currently has 15 source rows whose `raw_file_path` is the placeholder `NULL`.
This does not break the foreign-key checks above, but it should be replaced with the real submitted raw-file locator(s) before final submission.

## T2 — Foreign-key rejection

Expected:
- An offering using nonexistent `business_id = 999999` is rejected.
- An offering using nonexistent `service_id = 999999` is rejected.
- No T2 row remains in `business_service`.

Actual MySQL result: **RUN IN WORKBENCH AND PASTE/CAPTURE THE ERROR HERE.**

Status: PENDING MYSQL EXECUTION

## T3 — Duplicate offering rejection

Expected:
- Re-inserting an existing `(business_id, service_id)` pair is rejected by the composite primary key.
- No `T3_DUPLICATE` row remains.

Actual MySQL result: **RUN IN WORKBENCH AND PASTE/CAPTURE ERROR 1062 HERE.**

Status: PENDING MYSQL EXECUTION

## T4 — Temporary missing-data fixture

Expected:
- Test Service A has exactly 2 providers.
- Both test businesses appear in the absent-Service-B NOT EXISTS check.
- Q5-style LEFT JOIN returns `9001` for Test Service A and `NULL` for Test Service B.
- Test Business One appears in the Q6-style query because its website is NULL.
- `ROLLBACK` removes all test rows.

Actual MySQL result: **RUN THE T4 BLOCK IN WORKBENCH AND RECORD THE RESULT GRIDS HERE.**

Status: PENDING MYSQL EXECUTION
